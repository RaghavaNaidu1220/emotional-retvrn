import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/config/theme_config.dart';
import '../../providers/practice_provider.dart';
import '../../models/practice_model.dart';
import 'practice_detail_screen.dart';

class PracticeLibraryScreen extends StatefulWidget {
  const PracticeLibraryScreen({Key? key}) : super(key: key);

  @override
  State<PracticeLibraryScreen> createState() => _PracticeLibraryScreenState();
}

class _PracticeLibraryScreenState extends State<PracticeLibraryScreen> {
  String _selectedCategory = 'All';
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();
  
  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    return Scaffold(
      backgroundColor: isDark ? const Color(0xFF0F172A) : const Color(0xFFFAFBFC),
      appBar: AppBar(
        title: const Text('Practice Library'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Consumer<PracticeProvider>(
        builder: (context, practiceProvider, child) {
          if (practiceProvider.isLoading) {
            return _buildLoadingState();
          }
          
          if (practiceProvider.practices.isEmpty) {
            return _buildEmptyState();
          }
          
          // Filter practices by category and search query
          final filteredPractices = practiceProvider.practices.where((practice) {
            final matchesCategory = _selectedCategory == 'All' || practice.category == _selectedCategory;
            final matchesSearch = _searchQuery.isEmpty || 
                practice.title.toLowerCase().contains(_searchQuery.toLowerCase()) ||
                practice.description.toLowerCase().contains(_searchQuery.toLowerCase());
            return matchesCategory && matchesSearch;
          }).toList();
          
          return Column(
            children: [
              // Search bar
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'Search practices...',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide.none,
                    ),
                    filled: true,
                    fillColor: isDark ? const Color(0xFF1E293B) : Colors.white,
                    contentPadding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                  },
                ),
              ),
              
              // Category filter
              SizedBox(
                height: 40,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    _buildCategoryChip('All', isDark),
                    _buildCategoryChip('Meditation', isDark),
                    _buildCategoryChip('Breathing', isDark),
                    _buildCategoryChip('Mindfulness', isDark),
                    _buildCategoryChip('Emotional', isDark),
                    _buildCategoryChip('Spiral', isDark),
                    _buildCategoryChip('Journaling', isDark),
                  ],
                ),
              ),
              
              const SizedBox(height: 16),
              
              // Practices grid
              Expanded(
                child: filteredPractices.isEmpty
                    ? _buildNoResultsState()
                    : GridView.builder(
                        padding: const EdgeInsets.all(16),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 3, // 3 columns for smaller cards
                          childAspectRatio: 0.9, // More compact aspect ratio
                          crossAxisSpacing: 12,
                          mainAxisSpacing: 12,
                        ),
                        itemCount: filteredPractices.length,
                        itemBuilder: (context, index) {
                          final practice = filteredPractices[index];
                          return _buildCompactPracticeCard(practice, isDark);
                        },
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
  
  Widget _buildCategoryChip(String category, bool isDark) {
    final isSelected = _selectedCategory == category;
    
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: FilterChip(
        label: Text(category),
        selected: isSelected,
        onSelected: (selected) {
          setState(() {
            _selectedCategory = category;
          });
        },
        backgroundColor: isDark ? const Color(0xFF1E293B) : Colors.white,
        selectedColor: ThemeConfig.primaryPurple.withOpacity(0.2),
        checkmarkColor: ThemeConfig.primaryPurple,
        labelStyle: TextStyle(
          color: isSelected 
              ? ThemeConfig.primaryPurple 
              : (isDark ? Colors.white70 : Colors.black87),
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        ),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 0),
        visualDensity: VisualDensity.compact,
      ),
    );
  }
  
  Widget _buildCompactPracticeCard(PracticeModel practice, bool isDark) {
    final colors = _getCategoryColors(practice.category);
    
    return GestureDetector(
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => PracticeDetailScreen(practice: practice),
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF1E293B) : Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with gradient
            Container(
              height: 60, // Smaller height
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: colors,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(16),
                  topRight: Radius.circular(16),
                ),
              ),
              child: Center(
                child: Icon(
                  _getCategoryIcon(practice.category),
                  color: Colors.white,
                  size: 28,
                ),
              ),
            ),
            
            // Content
            Padding(
              padding: const EdgeInsets.all(10), // Smaller padding
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    practice.title,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14, // Smaller font
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2), // Smaller spacing
                  Text(
                    practice.description,
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 12, // Smaller font
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 6), // Smaller spacing
                  Row(
                    children: [
                      Icon(
                        Icons.schedule,
                        size: 12, // Smaller icon
                        color: Colors.grey[500],
                      ),
                      const SizedBox(width: 4),
                      Text(
                        practice.duration,
                        style: TextStyle(
                          color: Colors.grey[600],
                          fontSize: 11, // Smaller font
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  IconData _getCategoryIcon(String category) {
    switch (category) {
      case 'Meditation':
        return Icons.self_improvement;
      case 'Breathing':
        return Icons.air;
      case 'Mindfulness':
        return Icons.spa;
      case 'Emotional':
        return Icons.favorite;
      case 'Spiral':
        return Icons.psychology;
      case 'Journaling':
        return Icons.edit_note;
      default:
        return Icons.fitness_center;
    }
  }
  
  List<Color> _getCategoryColors(String category) {
    switch (category) {
      case 'Meditation':
        return [ThemeConfig.primaryPurple, ThemeConfig.primaryBlue];
      case 'Breathing':
        return [ThemeConfig.primaryBlue, ThemeConfig.primaryGreen];
      case 'Mindfulness':
        return [ThemeConfig.primaryGreen, ThemeConfig.primaryYellow];
      case 'Emotional':
        return [ThemeConfig.primaryYellow, ThemeConfig.primaryOrange];
      case 'Spiral':
        return [ThemeConfig.primaryOrange, ThemeConfig.primaryRed];
      case 'Journaling':
        return [ThemeConfig.primaryRed, ThemeConfig.primaryPink];
      default:
        return ThemeConfig.primaryGradient;
    }
  }
  
  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: ThemeConfig.primaryGradient,
              ),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const CircularProgressIndicator(
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'Loading practices...',
            style: Theme.of(context).textTheme.titleMedium,
          ),
        ],
      ),
    );
  }
  
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: ThemeConfig.primaryPurple.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Icon(
              Icons.fitness_center,
              size: 64,
              color: ThemeConfig.primaryPurple,
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'No practices available',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          Text(
            'Check back later for new content',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
              color: Colors.grey[600],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildNoResultsState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: ThemeConfig.primaryBlue.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Icon(
              Icons.search_off,
              size: 64,
              color: ThemeConfig.primaryBlue,
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'No matching practices',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          Text(
            'Try adjusting your filters',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
              color: Colors.grey[600],
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: () {
              setState(() {
                _selectedCategory = 'All';
                _searchQuery = '';
                _searchController.clear();
              });
            },
            icon: const Icon(Icons.refresh),
            label: const Text('Reset filters'),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
