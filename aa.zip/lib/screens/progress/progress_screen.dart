import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';
import '../../providers/journal_provider.dart';
import '../../core/config/app_config.dart';

class ProgressScreen extends StatefulWidget {
  const ProgressScreen({super.key});

  @override
  State<ProgressScreen> createState() => _ProgressScreenState();
}

class _ProgressScreenState extends State<ProgressScreen> {
  int _selectedTabIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Consumer<JournalProvider>(
      builder: (context, journalProvider, child) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('Progress Tracker'),
          ),
          body: Column(
            children: [
              // Tab Bar
              Container(
                margin: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => setState(() => _selectedTabIndex = 0),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: _selectedTabIndex == 0 
                                ? Theme.of(context).colorScheme.primary 
                                : Colors.transparent,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            'Emotions',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: _selectedTabIndex == 0 
                                  ? Colors.white 
                                  : Colors.grey[600],
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ),
                    Expanded(
                      child: GestureDetector(
                        onTap: () => setState(() => _selectedTabIndex = 1),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: _selectedTabIndex == 1 
                                ? Theme.of(context).colorScheme.primary 
                                : Colors.transparent,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Text(
                            'Spiral Stages',
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: _selectedTabIndex == 1 
                                  ? Colors.white 
                                  : Colors.grey[600],
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              
              // Content
              Expanded(
                child: _selectedTabIndex == 0 
                    ? _buildEmotionChart(journalProvider)
                    : _buildSpiralChart(journalProvider),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildEmotionChart(JournalProvider journalProvider) {
    if (journalProvider.analyses.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.sentiment_neutral, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text(
              'No emotion data yet',
              style: TextStyle(fontSize: 18, color: Colors.grey),
            ),
            SizedBox(height: 8),
            Text(
              'Start journaling to see your emotional patterns',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      );
    }

    // Aggregate emotion data
    final Map<String, double> emotionTotals = {};
    for (final analysis in journalProvider.analyses) {
      for (final entry in analysis.emotions.entries) {
        emotionTotals[entry.key] = (emotionTotals[entry.key] ?? 0) + entry.value;
      }
    }

    final sortedEmotions = emotionTotals.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Emotion Distribution',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          
          // Pie Chart
          SizedBox(
            height: 300,
            child: PieChart(
              PieChartData(
                sections: sortedEmotions.take(6).map((entry) {
                  final index = sortedEmotions.indexOf(entry);
                  return PieChartSectionData(
                    value: entry.value,
                    title: '${entry.key}\n${(entry.value / emotionTotals.values.reduce((a, b) => a + b) * 100).round()}%',
                    color: _getEmotionColor(entry.key),
                    radius: 100,
                    titleStyle: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  );
                }).toList(),
                centerSpaceRadius: 40,
                sectionsSpace: 2,
              ),
            ),
          ),
          
          const SizedBox(height: 24),
          
          // Emotion List
          Text(
            'Detailed Breakdown',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          
          ...sortedEmotions.map((entry) {
            final percentage = (entry.value / emotionTotals.values.reduce((a, b) => a + b) * 100).round();
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: Container(
                  width: 24,
                  height: 24,
                  decoration: BoxDecoration(
                    color: _getEmotionColor(entry.key),
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                title: Text(entry.key),
                trailing: Text(
                  '$percentage%',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            );
          }).toList(),
        ],
      ),
    );
  }

  Widget _buildSpiralChart(JournalProvider journalProvider) {
    if (journalProvider.analyses.isEmpty) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.psychology, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text(
              'No spiral dynamics data yet',
              style: TextStyle(fontSize: 18, color: Colors.grey),
            ),
            SizedBox(height: 8),
            Text(
              'Start journaling to track your consciousness evolution',
              style: TextStyle(color: Colors.grey),
            ),
          ],
        ),
      );
    }

    // Aggregate spiral stage data
    final Map<String, int> stageCounts = {};
    for (final analysis in journalProvider.analyses) {
      stageCounts[analysis.spiralColor] = (stageCounts[analysis.spiralColor] ?? 0) + 1;
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Spiral Dynamics Evolution',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          
          // Bar Chart
          SizedBox(
            height: 300,
            child: BarChart(
              BarChartData(
                alignment: BarChartAlignment.spaceAround,
                maxY: stageCounts.values.isNotEmpty 
                    ? stageCounts.values.reduce((a, b) => a > b ? a : b).toDouble() + 1
                    : 10,
                barGroups: stageCounts.entries.map((entry) {
                  final index = AppConfig.spiralColors.keys.toList().indexOf(entry.key);
                  return BarChartGroupData(
                    x: index,
                    barRods: [
                      BarChartRodData(
                        toY: entry.value.toDouble(),
                        color: Color(AppConfig.spiralColors[entry.key]?['color'] ?? 0xFF6750A4),
                        width: 20,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ],
                  );
                }).toList(),
                titlesData: FlTitlesData(
                  leftTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: true),
                  ),
                  bottomTitles: AxisTitles(
                    sideTitles: SideTitles(
                      showTitles: true,
                      getTitlesWidget: (value, meta) {
                        final stages = AppConfig.spiralColors.keys.toList();
                        if (value.toInt() < stages.length) {
                          return Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Text(
                              stages[value.toInt()].toUpperCase(),
                              style: const TextStyle(fontSize: 10),
                            ),
                          );
                        }
                        return const Text('');
                      },
                    ),
                  ),
                  rightTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                  topTitles: const AxisTitles(
                    sideTitles: SideTitles(showTitles: false),
                  ),
                ),
                borderData: FlBorderData(show: false),
                gridData: const FlGridData(show: true),
              ),
            ),
          ),
          
          const SizedBox(height: 24),
          
          // Stage Details
          Text(
            'Stage Distribution',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),
          
          ...stageCounts.entries.map((entry) {
            final stageInfo = AppConfig.spiralColors[entry.key];
            final percentage = (entry.value / journalProvider.analyses.length * 100).round();
            
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: Container(
                  width: 24,
                  height: 24,
                  decoration: BoxDecoration(
                    color: Color(stageInfo?['color'] ?? 0xFF6750A4),
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                title: Text(stageInfo?['name'] ?? entry.key),
                subtitle: Text(stageInfo?['description'] ?? ''),
                trailing: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      '${entry.value}',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      '$percentage%',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        ],
      ),
    );
  }

  Color _getEmotionColor(String emotion) {
    switch (emotion.toLowerCase()) {
      case 'joy':
      case 'happiness':
      case 'excitement':
        return Colors.yellow[700]!;
      case 'sadness':
      case 'grief':
        return Colors.blue[700]!;
      case 'anger':
      case 'frustration':
        return Colors.red[700]!;
      case 'fear':
      case 'anxiety':
        return Colors.purple[700]!;
      case 'love':
      case 'gratitude':
        return Colors.pink[700]!;
      case 'calm':
      case 'peace':
        return Colors.green[700]!;
      default:
        return Colors.grey[700]!;
    }
  }
}
