import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/journal_provider.dart';
import '../../models/journal_model.dart';
import '../../services/openai_service.dart';
import '../../core/config/theme_config.dart';

class VoiceJournalScreen extends StatefulWidget {
  const VoiceJournalScreen({super.key});

  @override
  State<VoiceJournalScreen> createState() => _VoiceJournalScreenState();
}

class _VoiceJournalScreenState extends State<VoiceJournalScreen> {
  final TextEditingController _textController = TextEditingController();
  final OpenAIService _openAIService = OpenAIService();
  
  bool _isAnalyzing = false;
  bool _isSaving = false;
  Map<String, dynamic>? _analysisResult;
  String _status = 'Ready to analyze';

  // Predefined sample texts
  final List<String> _sampleTexts = [
    "I'm feeling really happy today. Everything seems to be going well and I'm grateful for all the good things in my life.",
    "I've been feeling quite anxious lately. Work has been stressful and I'm worried about meeting all my deadlines.",
    "Today was a difficult day. I felt sad and overwhelmed by everything that's happening around me.",
    "I'm feeling calm and peaceful. I spent some time in nature and it really helped me relax and find my center.",
    "I'm excited about the future! There are so many opportunities ahead and I feel motivated to pursue my goals.",
  ];

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  void _useSampleText() {
    final randomText = (_sampleTexts..shuffle()).first;
    setState(() {
      _textController.text = randomText;
      _status = 'Sample text loaded - ready to analyze';
      _analysisResult = null;
    });
  }

  Future<void> _analyzeText() async {
    final text = _textController.text.trim();
    if (text.isEmpty) {
      setState(() {
        _status = 'Please add some text to analyze';
      });
      return;
    }

    setState(() {
      _isAnalyzing = true;
      _status = 'Analyzing your thoughts...';
    });

    try {
      // Use OpenAI service for analysis
      final analysis = await _openAIService.analyzeEmotion(text);
      
      setState(() {
        _analysisResult = {
          'emotion': _extractEmotion(text),
          'mood': _determineMood(text),
          'insights': analysis['insights'] ?? 'Your thoughts show depth and self-reflection.',
          'suggestions': analysis['suggestions'] ?? 'Consider exploring these feelings further through journaling.',
          'sentiment': _analyzeSentiment(text),
          'keywords': _extractKeywords(text),
        };
        _status = 'Analysis complete!';
      });
      
    } catch (e) {
      // Fallback to local analysis if OpenAI fails
      setState(() {
        _analysisResult = {
          'emotion': _extractEmotion(text),
          'mood': _determineMood(text),
          'insights': 'Your thoughts show depth and self-reflection. This entry reveals important aspects of your emotional state.',
          'suggestions': 'Consider exploring these feelings further through journaling or speaking with someone you trust.',
          'sentiment': _analyzeSentiment(text),
          'keywords': _extractKeywords(text),
        };
        _status = 'Analysis complete (offline mode)';
      });
    } finally {
      setState(() {
        _isAnalyzing = false;
      });
    }
  }

  String _extractEmotion(String text) {
    final lowerText = text.toLowerCase();
    if (lowerText.contains(RegExp(r'\b(happy|joy|excited|great|amazing|wonderful|glad|cheerful|delighted)\b'))) {
      return 'Happy';
    } else if (lowerText.contains(RegExp(r'\b(sad|depressed|down|upset|disappointed|heartbroken|melancholy)\b'))) {
      return 'Sad';
    } else if (lowerText.contains(RegExp(r'\b(angry|mad|frustrated|annoyed|irritated|furious|rage)\b'))) {
      return 'Angry';
    } else if (lowerText.contains(RegExp(r'\b(anxious|worried|nervous|stressed|overwhelmed|panic|fear)\b'))) {
      return 'Anxious';
    } else if (lowerText.contains(RegExp(r'\b(calm|peaceful|relaxed|content|serene|tranquil|zen)\b'))) {
      return 'Calm';
    } else if (lowerText.contains(RegExp(r'\b(excited|enthusiastic|motivated|energetic|pumped)\b'))) {
      return 'Excited';
    } else {
      return 'Neutral';
    }
  }

  String _determineMood(String text) {
    final emotion = _extractEmotion(text);
    switch (emotion) {
      case 'Happy':
      case 'Excited':
        return 'Positive';
      case 'Sad':
      case 'Angry':
        return 'Negative';
      case 'Anxious':
        return 'Tense';
      case 'Calm':
        return 'Peaceful';
      default:
        return 'Balanced';
    }
  }

  String _analyzeSentiment(String text) {
    final positiveWords = ['good', 'great', 'amazing', 'wonderful', 'happy', 'love', 'excellent', 'fantastic', 'awesome', 'brilliant'];
    final negativeWords = ['bad', 'terrible', 'awful', 'hate', 'horrible', 'sad', 'angry', 'frustrated', 'disappointed', 'worried'];
    
    final lowerText = text.toLowerCase();
    int positiveCount = 0;
    int negativeCount = 0;
    
    for (String word in positiveWords) {
      if (lowerText.contains(word)) positiveCount++;
    }
    
    for (String word in negativeWords) {
      if (lowerText.contains(word)) negativeCount++;
    }
    
    if (positiveCount > negativeCount) {
      return 'Positive';
    } else if (negativeCount > positiveCount) {
      return 'Negative';
    } else {
      return 'Neutral';
    }
  }

  List<String> _extractKeywords(String text) {
    final emotionalKeywords = ['happy', 'sad', 'angry', 'anxious', 'calm', 'excited', 'worried', 'stressed', 'peaceful', 'grateful', 'frustrated', 'overwhelmed'];
    final lowerText = text.toLowerCase();
    final foundKeywords = <String>[];
    
    for (String keyword in emotionalKeywords) {
      if (lowerText.contains(keyword)) {
        foundKeywords.add(keyword);
      }
    }
    
    return foundKeywords.take(5).toList();
  }

  Future<void> _saveJournal() async {
    final content = _textController.text.trim();
    if (content.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please add some content to save')),
      );
      return;
    }

    setState(() {
      _isSaving = true;
      _status = 'Saving journal entry...';
    });

    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      final journalProvider = Provider.of<JournalProvider>(context, listen: false);
      
      final userId = authProvider.currentUser?.id ?? 'demo_user_123';
      final journal = JournalModel(
        userId: userId,
        content: content,
        transcript: content, // Same as content since it's text input
        createdAt: DateTime.now(),
      );

      final success = await journalProvider.createJournal(journal);
      
      if (success && mounted) {
        setState(() {
          _status = 'Journal saved successfully!';
        });
        
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Journal entry saved successfully!'),
            backgroundColor: Colors.green,
          ),
        );
        
        // Clear the form
        _textController.clear();
        setState(() {
          _analysisResult = null;
          _status = 'Ready to analyze';
        });
        
      } else {
        setState(() {
          _status = 'Failed to save journal';
        });
      }
    } catch (e) {
      setState(() {
        _status = 'Error saving journal: $e';
      });
    } finally {
      setState(() {
        _isSaving = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFAFBFC),
      appBar: AppBar(
        title: const Row(
          children: [
            Icon(Icons.psychology, color: ThemeConfig.primaryBlue),
            SizedBox(width: 8),
            Text('Text Analysis Journal'),
          ],
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        foregroundColor: Colors.black87,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              // Status Card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.05),
                      blurRadius: 10,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Icon(
                      Icons.analytics,
                      size: 32,
                      color: ThemeConfig.primaryBlue,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _status,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: 24),
              
              // Sample Text Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _useSampleText,
                  icon: const Icon(Icons.auto_awesome),
                  label: const Text('Use Sample Text'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: ThemeConfig.primaryPurple,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
              
              const SizedBox(height: 16),
              
              // Text Input
              Expanded(
                flex: 2,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 10,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: TextField(
                    controller: _textController,
                    maxLines: null,
                    expands: true,
                    decoration: const InputDecoration(
                      hintText: 'Type your thoughts here or use sample text...',
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.all(16),
                    ),
                    style: const TextStyle(fontSize: 16),
                  ),
                ),
              ),
              
              const SizedBox(height: 16),
              
              // Analysis Results
              if (_analysisResult != null) ...[
                Expanded(
                  flex: 2,
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 10,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Analysis Results',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 12),
                          
                          // Emotion and Mood Tags
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: [
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  color: ThemeConfig.primaryBlue.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  'Emotion: ${_analysisResult!['emotion']}',
                                  style: const TextStyle(
                                    color: ThemeConfig.primaryBlue,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  color: ThemeConfig.primaryGreen.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  'Mood: ${_analysisResult!['mood']}',
                                  style: const TextStyle(
                                    color: ThemeConfig.primaryGreen,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  color: ThemeConfig.primaryPurple.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  'Sentiment: ${_analysisResult!['sentiment']}',
                                  style: const TextStyle(
                                    color: ThemeConfig.primaryPurple,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          
                          const SizedBox(height: 16),
                          
                          // Keywords
                          if (_analysisResult!['keywords'].isNotEmpty) ...[
                            const Text(
                              'Key Emotions:',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Wrap(
                              spacing: 4,
                              children: (_analysisResult!['keywords'] as List<String>)
                                  .map((keyword) => Chip(
                                        label: Text(keyword),
                                        backgroundColor: Colors.grey.shade100,
                                        labelStyle: const TextStyle(fontSize: 12),
                                      ))
                                  .toList(),
                            ),
                            const SizedBox(height: 12),
                          ],
                          
                          // Insights
                          const Text(
                            'Insights:',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _analysisResult!['insights'],
                            style: const TextStyle(fontSize: 14),
                          ),
                          
                          const SizedBox(height: 12),
                          
                          // Suggestions
                          const Text(
                            'Suggestions:',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _analysisResult!['suggestions'],
                            style: const TextStyle(fontSize: 14),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
              ],
              
              // Action Buttons
              Row(
                children: [
                  if (_textController.text.isNotEmpty) ...[
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _isAnalyzing ? null : _analyzeText,
                        icon: _isAnalyzing 
                            ? const SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.analytics),
                        label: Text(_isAnalyzing ? 'Analyzing...' : 'Analyze'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: ThemeConfig.primaryBlue,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                  ],
                  
                  if (_textController.text.isNotEmpty) ...[
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _isSaving ? null : _saveJournal,
                        icon: _isSaving 
                            ? const SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.save),
                        label: Text(_isSaving ? 'Saving...' : 'Save'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: ThemeConfig.primaryGreen,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
