import 'package:flutter/material.dart';
import 'dart:html' as html;
import 'dart:js' as js;
import 'dart:async';

class SimpleVoiceService {
  static final SimpleVoiceService _instance = SimpleVoiceService._internal();
  factory SimpleVoiceService() => _instance;
  SimpleVoiceService._internal();

  dynamic _recognition;
  bool _isListening = false;
  String _lastTranscript = '';
  
  // Simple voice to text
  Future<String?> getVoiceText() async {
    try {
      // Check if browser supports speech recognition
      if (!js.context.hasProperty('webkitSpeechRecognition')) {
        throw Exception('Speech recognition not supported. Please use Chrome.');
      }

      // Create speech recognition
      _recognition = js.JsObject(js.context['webkitSpeechRecognition']);
      
      // Configure
      _recognition['lang'] = 'en-US';
      _recognition['continuous'] = false;
      _recognition['interimResults'] = false;
      
      final completer = Completer<String?>();
      
      // Handle result
      _recognition['onresult'] = js.allowInterop((event) {
        try {
          final transcript = event['results'][0][0]['transcript'];
          _lastTranscript = transcript.toString().trim();
          completer.complete(_lastTranscript);
        } catch (e) {
          completer.complete(null);
        }
      });
      
      // Handle errors
      _recognition['onerror'] = js.allowInterop((event) {
        completer.completeError('Speech recognition failed');
      });
      
      // Handle end
      _recognition['onend'] = js.allowInterop(() {
        _isListening = false;
        if (!completer.isCompleted) {
          completer.complete(_lastTranscript.isEmpty ? null : _lastTranscript);
        }
      });
      
      // Start listening
      _isListening = true;
      _recognition.callMethod('start');
      
      // Wait for result with timeout
      return await completer.future.timeout(
        const Duration(seconds: 10),
        onTimeout: () {
          _recognition?.callMethod('stop');
          return _lastTranscript.isEmpty ? null : _lastTranscript;
        },
      );
      
    } catch (e) {
      debugPrint('Voice recognition error: $e');
      return null;
    }
  }
  
  void stopListening() {
    if (_recognition != null && _isListening) {
      _recognition.callMethod('stop');
      _isListening = false;
    }
  }
  
  bool get isListening => _isListening;
}
