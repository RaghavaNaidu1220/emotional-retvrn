import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import '../core/config/app_config.dart';

class AIChatService {
  static const String _baseUrl = 'https://api.openai.com/v1';
  
  Future<String> getReflectiveQuestion(String? previousEntry) async {
    final apiKey = AppConfig.openAIApiKey;
    
    try {
      debugPrint('Getting reflective question from AI...');
      
      String prompt = '''You are an emotionally intelligent journaling assistant. Your role is to ask thoughtful, reflective questions that help users explore their emotions and experiences deeper.

Ask ONE reflective question that:
- Is warm and compassionate
- Encourages self-discovery
- Is specific and actionable
- Feels like a caring friend asking

${previousEntry != null ? 'Based on this previous entry: "$previousEntry"' : 'For someone starting their journaling journey'}

Respond with just the question, no extra text.''';

      final response = await http.post(
        Uri.parse('$_baseUrl/chat/completions'),
        headers: {
          'Authorization': 'Bearer $apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'model': 'gpt-4o-mini',
          'messages': [
            {
              'role': 'system',
              'content': 'You are a compassionate journaling assistant who asks thoughtful questions.'
            },
            {
              'role': 'user',
              'content': prompt,
            }
          ],
          'temperature': 0.7,
          'max_tokens': 100,
        }),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final question = data['choices'][0]['message']['content'].trim();
        debugPrint('AI reflective question generated');
        return question;
      } else {
        debugPrint('OpenAI API error: ${response.statusCode}');
        return _getDefaultQuestion();
      }
    } catch (e) {
      debugPrint('Error getting reflective question: $e');
      return _getDefaultQuestion();
    }
  }
  
  Future<String> getEmotionalInsight(List<String> recentEntries) async {
    final apiKey = AppConfig.openAIApiKey;
    
    try {
      debugPrint('Getting emotional insight from AI...');
      
      String entriesText = recentEntries.join('\n\n---\n\n');
      
      String prompt = '''Based on these recent journal entries, provide a compassionate insight about the person's emotional patterns or growth:

$entriesText

Provide ONE insight that:
- Is encouraging and supportive
- Identifies a positive pattern or growth area
- Feels like a caring friend's observation
- Is specific to their entries
- Ends with a gentle suggestion or affirmation

Start with "I notice that..." or "It seems like..." and keep it warm and personal.''';

      final response = await http.post(
        Uri.parse('$_baseUrl/chat/completions'),
        headers: {
          'Authorization': 'Bearer $apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'model': 'gpt-4o-mini',
          'messages': [
            {
              'role': 'system',
              'content': 'You are a compassionate emotional intelligence coach who provides gentle insights.'
            },
            {
              'role': 'user',
              'content': prompt,
            }
          ],
          'temperature': 0.6,
          'max_tokens': 150,
        }),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final insight = data['choices'][0]['message']['content'].trim();
        debugPrint('AI emotional insight generated');
        return insight;
      } else {
        debugPrint('OpenAI API error: ${response.statusCode}');
        return _getDefaultInsight();
      }
    } catch (e) {
      debugPrint('Error getting emotional insight: $e');
      return _getDefaultInsight();
    }
  }
  
  Future<String> getFollowUpQuestion(String currentEntry) async {
    final apiKey = AppConfig.openAIApiKey;
    
    try {
      debugPrint('Getting follow-up question from AI...');
      
      String prompt = '''Based on this journal entry, ask ONE thoughtful follow-up question that helps them explore deeper:

"$currentEntry"

The question should:
- Help them explore the "why" behind their feelings
- Encourage deeper self-reflection
- Be specific to what they shared
- Feel supportive and curious, not intrusive

Respond with just the question.''';

      final response = await http.post(
        Uri.parse('$_baseUrl/chat/completions'),
        headers: {
          'Authorization': 'Bearer $apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'model': 'gpt-4o-mini',
          'messages': [
            {
              'role': 'system',
              'content': 'You are a thoughtful journaling companion who asks insightful follow-up questions.'
            },
            {
              'role': 'user',
              'content': prompt,
            }
          ],
          'temperature': 0.7,
          'max_tokens': 80,
        }),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final question = data['choices'][0]['message']['content'].trim();
        debugPrint('AI follow-up question generated');
        return question;
      } else {
        debugPrint('OpenAI API error: ${response.statusCode}');
        return _getDefaultFollowUp();
      }
    } catch (e) {
      debugPrint('Error getting follow-up question: $e');
      return _getDefaultFollowUp();
    }
  }
  
  String _getDefaultQuestion() {
    final questions = [
      "What made you feel most alive today?",
      "What emotion are you carrying with you right now?",
      "What would you like to let go of today?",
      "What are you grateful for in this moment?",
      "How did you show kindness to yourself today?",
      "What challenged you today, and how did you respond?",
      "What brought you peace today?",
    ];
    questions.shuffle();
    return questions.first;
  }
  
  String _getDefaultInsight() {
    return "I notice that you're taking time to reflect on your experiences, which shows real emotional awareness. This practice of self-reflection is a beautiful way to understand yourself better.";
  }
  
  String _getDefaultFollowUp() {
    return "What do you think this experience is teaching you about yourself?";
  }
}
