import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../core/config/app_config.dart';
import '../models/user_model.dart';
import '../models/journal_model.dart';
import '../models/emotion_analysis_model.dart';

class SupabaseService {
  final SupabaseClient _client = Supabase.instance.client;
  
  // Authentication - strict database only
  Future<AuthResponse> signIn(String email, String password) async {
    debugPrint('Signing in with email: $email');
    
    try {
      final response = await _client.auth.signInWithPassword(
        email: email,
        password: password,
      );
      
      if (response.user == null) {
        throw Exception('Authentication failed - no user returned');
      }
      
      debugPrint('Sign in successful for user: ${response.user?.email}');
      return response;
    } catch (e) {
      debugPrint('Supabase sign in error: $e');
      rethrow; // Re-throw the original error
    }
  }
  
  Future<AuthResponse> signUp(String email, String password) async {
    debugPrint('Signing up with email: $email');
    
    try {
      final response = await _client.auth.signUp(
        email: email,
        password: password,
      );
      
      if (response.user == null) {
        throw Exception('Registration failed - no user returned');
      }
      
      debugPrint('Sign up successful for user: ${response.user?.email}');
      return response;
    } catch (e) {
      debugPrint('Supabase sign up error: $e');
      rethrow; // Re-throw the original error
    }
  }
  
  Future<void> signOut() async {
    try {
      await _client.auth.signOut();
      debugPrint('Sign out successful');
    } catch (e) {
      debugPrint('Supabase sign out error: $e');
      rethrow;
    }
    
    // Clear local storage
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
  
  // User Profile - database only, no fallbacks
  Future<void> createUserProfile(String userId, String name, String email) async {
    debugPrint('Creating user profile for: $userId');
    
    final user = UserModel(
      id: userId,
      email: email,
      name: name,
      spiralStage: 'beige',
      createdAt: DateTime.now(),
    );
    
    try {
      await _client.from('users').insert(user.toJson());
      debugPrint('User profile created successfully in database');
    } catch (e) {
      debugPrint('Failed to create user profile in database: $e');
      throw Exception('Failed to create user profile: $e');
    }
  }
  
  Future<UserModel> getUserProfile(String userId) async {
    debugPrint('Loading user profile for: $userId');
    
    try {
      final response = await _client
          .from('users')
          .select()
          .eq('id', userId)
          .single();
      
      debugPrint('User profile loaded from database');
      return UserModel.fromJson(response);
    } catch (e) {
      debugPrint('Failed to load user profile from database: $e');
      throw Exception('Failed to load user profile: $e');
    }
  }
  
  Future<void> updateUserProfile(UserModel user) async {
    debugPrint('Updating user profile for: ${user.id}');
    
    try {
      await _client.from('users').update({
        'name': user.name,
        'email': user.email,
        'age': user.age,
        'spiral_stage': user.spiralStage,
        'updated_at': DateTime.now().toIso8601String(),
      }).eq('id', user.id);
      
      debugPrint('User profile updated successfully in database');
    } catch (e) {
      debugPrint('Failed to update user profile in database: $e');
      throw Exception('Failed to update user profile: $e');
    }
  }
  
  // Journals - database only
  Future<JournalModel> createJournal(JournalModel journal) async {
    debugPrint('Creating journal for user: ${journal.userId}');
    
    try {
      final response = await _client
          .from('journals')
          .insert(journal.toJson())
          .select()
          .single();
      
      debugPrint('Journal created successfully in database');
      return JournalModel.fromJson(response);
    } catch (e) {
      debugPrint('Failed to create journal in database: $e');
      throw Exception('Failed to create journal: $e');
    }
  }
  
  Future<List<JournalModel>> getUserJournals(String userId) async {
    debugPrint('Loading journals for user: $userId');
    
    try {
      final response = await _client
          .from('journals')
          .select()
          .eq('user_id', userId)
          .order('created_at', ascending: false);
      
      debugPrint('Loaded ${response.length} journals from database');
      return (response as List)
          .map((json) => JournalModel.fromJson(json))
          .toList();
    } catch (e) {
      debugPrint('Failed to load journals from database: $e');
      throw Exception('Failed to load journals: $e');
    }
  }
  
  // Emotion Analysis - database only
  Future<void> saveEmotionAnalysis(EmotionAnalysisModel analysis) async {
    debugPrint('Saving emotion analysis for journal: ${analysis.journalId}');
    
    try {
      await _client.from('emotion_analysis').insert(analysis.toJson());
      debugPrint('Emotion analysis saved successfully in database');
    } catch (e) {
      debugPrint('Failed to save emotion analysis in database: $e');
      throw Exception('Failed to save emotion analysis: $e');
    }
  }
  
  Future<List<EmotionAnalysisModel>> getEmotionAnalyses(String userId) async {
    debugPrint('Loading emotion analyses for user: $userId');
    
    try {
      // Use a join query to get analyses for user's journals
      final response = await _client
          .from('emotion_analysis')
          .select('''
            *,
            journals!inner(user_id)
          ''')
          .eq('journals.user_id', userId)
          .order('created_at', ascending: false);
      
      debugPrint('Loaded ${response.length} emotion analyses from database');
      return (response as List)
          .map((json) => EmotionAnalysisModel.fromJson(json))
          .toList();
    } catch (e) {
      debugPrint('Failed to load emotion analyses from database: $e');
      throw Exception('Failed to load emotion analyses: $e');
    }
  }
  
  // File Upload (not implemented)
  Future<String> uploadAudio(String filePath, String fileName) async {
    throw Exception('Audio upload not implemented');
  }
}
