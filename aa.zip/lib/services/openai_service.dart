import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import '../core/config/app_config.dart';

class OpenAIService {
  static const String _baseUrl = 'https://api.openai.com/v1';
  
  Future<Map<String, dynamic>> analyzeEmotion(String text) async {
    final apiKey = AppConfig.openAIApiKey;
    
    try {
      debugPrint('Analyzing emotion with OpenAI...');
      final response = await http.post(
        Uri.parse('$_baseUrl/chat/completions'),
        headers: {
          'Authorization': 'Bearer $apiKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'model': 'gpt-3.5-turbo',
          'messages': [
            {
              'role': 'system',
              'content': '''You are an expert in emotional analysis and Spiral Dynamics psychology. 
              Analyze the given text and provide:
              1. Primary emotions detected (with confidence scores 0-1)
              2. Spiral Dynamics stage (beige, purple, red, blue, orange, green, yellow, turquoise)
              3. Growth suggestions
              4. Confidence score for the analysis
              
              Respond in JSON format:
              {
                "emotions": {"emotion": confidence_score},
                "spiral_stage": "stage_name",
                "suggestions": ["suggestion1", "suggestion2"],
                "confidence": 0.85
              }'''
            },
            {
              'role': 'user',
              'content': text,
            }
          ],
          'temperature': 0.3,
        }),
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final content = data['choices'][0]['message']['content'];
        debugPrint('OpenAI analysis successful');
        return jsonDecode(content);
      } else {
        debugPrint('OpenAI API error: ${response.statusCode} - ${response.body}');
        return _getMockAnalysis(text);
      }
    } catch (e) {
      debugPrint('Error in emotion analysis: $e');
      return _getMockAnalysis(text);
    }
  }

  Future<String> extractEmotionalInsights(String text) async {
    try {
      debugPrint('Extracting emotional insights...');
      
      // Mock insights based on text analysis
      final insights = _generateInsights(text);
      await Future.delayed(const Duration(milliseconds: 500)); // Simulate API call
      
      debugPrint('Emotional insights extracted: $insights');
      return insights;
    } catch (e) {
      debugPrint('Error extracting insights: $e');
      return 'Unable to extract insights at this time.';
    }
  }

  Future<List<String>> identifyEmotionalPatterns(String text) async {
    try {
      debugPrint('Identifying emotional patterns...');
      
      // Mock pattern identification
      final patterns = _identifyPatterns(text);
      await Future.delayed(const Duration(milliseconds: 500)); // Simulate API call
      
      debugPrint('Emotional patterns identified: $patterns');
      return patterns;
    } catch (e) {
      debugPrint('Error identifying patterns: $e');
      return ['Unable to identify patterns at this time.'];
    }
  }

  Future<String> generateEmotionalSummary(String text) async {
    try {
      debugPrint('Generating emotional summary...');
      
      // Mock summary generation
      final summary = _generateSummary(text);
      await Future.delayed(const Duration(milliseconds: 500)); // Simulate API call
      
      debugPrint('Emotional summary generated: $summary');
      return summary;
    } catch (e) {
      debugPrint('Error generating summary: $e');
      return 'Unable to generate summary at this time.';
    }
  }

  String _generateInsights(String text) {
    final lowerText = text.toLowerCase();
    
    if (lowerText.contains('stress') || lowerText.contains('anxious')) {
      return 'You seem to be experiencing stress. Consider practicing deep breathing or mindfulness techniques.';
    } else if (lowerText.contains('happy') || lowerText.contains('joy')) {
      return 'Your positive emotions are shining through. This is a great time to reflect on what brings you joy.';
    } else if (lowerText.contains('sad') || lowerText.contains('down')) {
      return 'It\'s natural to feel down sometimes. Remember that these feelings are temporary and part of the human experience.';
    } else if (lowerText.contains('grateful') || lowerText.contains('thankful')) {
      return 'Gratitude is a powerful emotion that can enhance your overall well-being. Keep nurturing this positive mindset.';
    } else {
      return 'Your emotional expression shows depth and self-awareness. Continue this practice of reflection.';
    }
  }

  List<String> _identifyPatterns(String text) {
    final lowerText = text.toLowerCase();
    List<String> patterns = [];
    
    if (lowerText.contains('always') || lowerText.contains('never')) {
      patterns.add('Absolute thinking patterns detected');
    }
    if (lowerText.contains('should') || lowerText.contains('must')) {
      patterns.add('Self-imposed pressure patterns');
    }
    if (lowerText.contains('but') || lowerText.contains('however')) {
      patterns.add('Conflicted thinking patterns');
    }
    if (lowerText.contains('feel') || lowerText.contains('emotion')) {
      patterns.add('High emotional awareness');
    }
    if (lowerText.contains('goal') || lowerText.contains('achieve')) {
      patterns.add('Achievement-oriented thinking');
    }
    
    if (patterns.isEmpty) {
      patterns.add('Balanced emotional expression');
    }
    
    return patterns;
  }

  String _generateSummary(String text) {
    final lowerText = text.toLowerCase();
    final wordCount = text.split(' ').length;
    
    String emotionalTone = 'neutral';
    if (lowerText.contains('happy') || lowerText.contains('joy') || lowerText.contains('excited')) {
      emotionalTone = 'positive';
    } else if (lowerText.contains('sad') || lowerText.contains('stress') || lowerText.contains('anxious')) {
      emotionalTone = 'challenging';
    }
    
    return 'This ${wordCount}-word entry reflects a $emotionalTone emotional state. '
           'The content shows self-reflection and emotional awareness, which are positive signs of personal growth.';
  }
  
  Map<String, dynamic> _getMockAnalysis(String text) {
    // Simple keyword-based analysis for demo
    final lowerText = text.toLowerCase();
    Map<String, double> emotions = {};
    String spiralStage = 'blue';
    
    // Detect emotions based on keywords
    if (lowerText.contains('happy') || lowerText.contains('joy') || lowerText.contains('excited')) {
      emotions['joy'] = 0.8;
    }
    if (lowerText.contains('sad') || lowerText.contains('depressed') || lowerText.contains('down')) {
      emotions['sadness'] = 0.7;
    }
    if (lowerText.contains('angry') || lowerText.contains('frustrated') || lowerText.contains('mad')) {
      emotions['anger'] = 0.6;
      spiralStage = 'red';
    }
    if (lowerText.contains('anxious') || lowerText.contains('worried') || lowerText.contains('nervous')) {
      emotions['anxiety'] = 0.7;
    }
    if (lowerText.contains('grateful') || lowerText.contains('thankful')) {
      emotions['gratitude'] = 0.8;
      spiralStage = 'green';
    }
    if (lowerText.contains('love') || lowerText.contains('caring')) {
      emotions['love'] = 0.9;
      spiralStage = 'green';
    }
    
    // Default emotion if none detected
    if (emotions.isEmpty) {
      emotions['neutral'] = 0.6;
    }
    
    // Determine spiral stage based on content themes
    if (lowerText.contains('survival') || lowerText.contains('basic needs')) {
      spiralStage = 'beige';
    } else if (lowerText.contains('tradition') || lowerText.contains('family') || lowerText.contains('ritual')) {
      spiralStage = 'purple';
    } else if (lowerText.contains('power') || lowerText.contains('control') || lowerText.contains('dominance')) {
      spiralStage = 'red';
    } else if (lowerText.contains('order') || lowerText.contains('rules') || lowerText.contains('discipline')) {
      spiralStage = 'blue';
    } else if (lowerText.contains('success') || lowerText.contains('achievement') || lowerText.contains('goal')) {
      spiralStage = 'orange';
    } else if (lowerText.contains('community') || lowerText.contains('harmony') || lowerText.contains('equality')) {
      spiralStage = 'green';
    } else if (lowerText.contains('system') || lowerText.contains('integration') || lowerText.contains('complexity')) {
      spiralStage = 'yellow';
    } else if (lowerText.contains('holistic') || lowerText.contains('global') || lowerText.contains('universal')) {
      spiralStage = 'turquoise';
    }
    
    return {
      'emotions': emotions,
      'spiral_stage': spiralStage,
      'suggestions': _getSuggestions(spiralStage),
      'confidence': 0.75
    };
  }
  
  List<String> _getSuggestions(String stage) {
    switch (stage) {
      case 'beige':
        return ['Focus on meeting your basic needs', 'Ensure you have adequate rest and nutrition', 'Create a safe environment'];
      case 'purple':
        return ['Honor your traditions while staying open', 'Build community connections', 'Practice gratitude rituals'];
      case 'red':
        return ['Channel your energy constructively', 'Practice delayed gratification', 'Learn from consequences'];
      case 'blue':
        return ['Balance structure with flexibility', 'Question rigid beliefs', 'Practice compassion'];
      case 'orange':
        return ['Balance achievement with relationships', 'Consider impact on others', 'Practice collaboration'];
      case 'green':
        return ['Balance consensus with decision-making', 'Embrace healthy conflict', 'Develop systems thinking'];
      case 'yellow':
        return ['Practice integral thinking', 'Embrace paradox', 'Develop meta-cognitive skills'];
      case 'turquoise':
        return ['Embody integral awareness', 'Practice global thinking', 'Serve collective evolution'];
      default:
        return ['Practice mindfulness', 'Reflect on your experiences', 'Seek growth opportunities'];
    }
  }
  
  Future<String> transcribeAudio(String audioPath) async {
    // For web, we don't actually transcribe files
    throw Exception('Audio transcription not supported on web. Use speech-to-text instead.');
  }
}
