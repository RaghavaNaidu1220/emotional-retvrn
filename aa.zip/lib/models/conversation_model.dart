class ConversationMessage {
  final String text;
  final bool isUser;
  final DateTime timestamp;
  
  ConversationMessage({
    required this.text,
    required this.isUser,
    required this.timestamp,
  });
}

class ConversationSession {
  final String id;
  final String userId;
  final List<ConversationMessage> messages;
  final DateTime createdAt;
  final DateTime updatedAt;
  final Map<String, dynamic>? emotionAnalysis;
  
  ConversationSession({
    required this.id,
    required this.userId,
    required this.messages,
    required this.createdAt,
    required this.updatedAt,
    this.emotionAnalysis,
  });
}
