import 'package:flutter/material.dart';
import '../models/practice_model.dart';

class PracticeProvider extends ChangeNotifier {
  List<PracticeModel> _practices = [];
  bool _isLoading = false;
  String? _errorMessage;
  
  List<PracticeModel> get practices => _practices;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  
  Future<void> loadPractices() async {
    _setLoading(true);
    _clearError();
    
    try {
      // Simulate loading delay
      await Future.delayed(const Duration(seconds: 1));
      
      // Mock practice data
      _practices = [
        PracticeModel(
          id: '1',
          title: 'Morning Meditation',
          description: 'Start your day with mindful awareness and intention setting',
          category: 'Meditation',
          duration: '10 min',
          difficulty: 'Beginner',
          hasVideo: true,
          hasAudio: false,
          videoUrl: 'assets/videos/loom_message.mp4',
          instructions: [
            'Find a comfortable seated position',
            'Close your eyes and focus on your breath',
            'Set an intention for your day',
            'Practice for 10 minutes'
          ],
          benefits: [
            'Reduces stress and anxiety',
            'Improves focus and clarity',
            'Enhances emotional well-being'
          ],
        ),
        PracticeModel(
          id: '2',
          title: 'Box Breathing',
          description: 'A powerful breathing technique for stress relief and focus',
          category: 'Breathing',
          duration: '5 min',
          difficulty: 'Beginner',
          hasVideo: true,
          hasAudio: false,
          videoUrl: 'assets/videos/loom_message.mp4',
          instructions: [
            'Inhale for 4 counts',
            'Hold for 4 counts',
            'Exhale for 4 counts',
            'Hold for 4 counts',
            'Repeat the cycle'
          ],
          benefits: [
            'Calms the nervous system',
            'Improves concentration',
            'Reduces anxiety'
          ],
        ),
        PracticeModel(
          id: '3',
          title: 'Body Scan',
          description: 'Progressive relaxation and mindfulness practice',
          category: 'Mindfulness',
          duration: '15 min',
          difficulty: 'Intermediate',
          hasVideo: true,
          hasAudio: false,
          videoUrl: 'assets/videos/loom_message.mp4',
          instructions: [
            'Lie down comfortably',
            'Start from your toes',
            'Slowly scan each part of your body',
            'Notice sensations without judgment'
          ],
          benefits: [
            'Releases physical tension',
            'Increases body awareness',
            'Promotes deep relaxation'
          ],
        ),
        PracticeModel(
          id: '4',
          title: 'Emotional Check-in',
          description: 'Guided practice for emotional awareness and regulation',
          category: 'Emotional Regulation',
          duration: '8 min',
          difficulty: 'Beginner',
          hasVideo: true,
          hasAudio: false,
          videoUrl: 'assets/videos/loom_message.mp4',
          instructions: [
            'Pause and take three deep breaths',
            'Notice what emotions are present',
            'Accept them without judgment',
            'Choose your response mindfully'
          ],
          benefits: [
            'Improves emotional intelligence',
            'Reduces reactivity',
            'Enhances self-awareness'
          ],
        ),
        PracticeModel(
          id: '5',
          title: 'Values Reflection',
          description: 'Explore your core values and align your actions',
          category: 'Spiral Dynamics',
          duration: '12 min',
          difficulty: 'Intermediate',
          hasVideo: true,
          hasAudio: false,
          videoUrl: 'assets/videos/loom_message.mp4',
          instructions: [
            'Reflect on what matters most to you',
            'Identify your top 5 values',
            'Consider how they guide your decisions',
            'Set intentions for value-aligned living'
          ],
          benefits: [
            'Clarifies personal direction',
            'Improves decision making',
            'Enhances life satisfaction'
          ],
        ),
        PracticeModel(
          id: '6',
          title: 'Gratitude Practice',
          description: 'Cultivate appreciation and positive mindset',
          category: 'Journaling',
          duration: '7 min',
          difficulty: 'Beginner',
          hasVideo: true,
          hasAudio: false,
          videoUrl: 'assets/videos/loom_message.mp4',
          instructions: [
            'Think of three things you\'re grateful for',
            'Write them down with details',
            'Feel the emotion of gratitude',
            'Share gratitude with someone'
          ],
          benefits: [
            'Boosts mood and happiness',
            'Improves relationships',
            'Enhances overall well-being'
          ],
        ),
      ];
      
      debugPrint('Loaded ${_practices.length} practices');
    } catch (e) {
      debugPrint('Error loading practices: $e');
      _setError('Failed to load practices: ${e.toString()}');
    } finally {
      _setLoading(false);
    }
  }
  
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }
  
  void _setError(String error) {
    _errorMessage = error;
    notifyListeners();
  }
  
  void _clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}
