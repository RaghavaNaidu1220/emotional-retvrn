import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';
import '../services/supabase_service.dart';

class AuthProvider extends ChangeNotifier {
  final SupabaseService _supabaseService = SupabaseService();
  
  User? _currentUser;
  UserModel? _userProfile;
  bool _isLoading = false;
  String? _errorMessage;
  bool _isProfileLoaded = false;
  
  User? get currentUser => _currentUser;
  UserModel? get userProfile => _userProfile;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  // Only authenticated if we have both user AND profile loaded from database
  bool get isAuthenticated => _currentUser != null && _userProfile != null && _isProfileLoaded;
  bool get isDemoMode => false; // No demo mode
  
  AuthProvider() {
    _initializeAuth();
  }
  
  void _initializeAuth() async {
    try {
      _currentUser = Supabase.instance.client.auth.currentUser;
      if (_currentUser != null) {
        await _loadUserProfile();
      }
      
      // Listen to auth changes
      Supabase.instance.client.auth.onAuthStateChange.listen((data) async {
        _currentUser = data.session?.user;
        if (_currentUser != null) {
          await _loadUserProfile();
        } else {
          _userProfile = null;
          _isProfileLoaded = false;
        }
        notifyListeners();
      });
    } catch (e) {
      debugPrint('Auth initialization error: $e');
      _setError('Failed to initialize authentication: $e');
    }
  }
  
  Future<bool> signIn(String email, String password) async {
    _setLoading(true);
    _clearError();
    
    try {
      await _supabaseService.signIn(email, password);
      // Profile will be loaded automatically via auth state change
      return true;
    } catch (e) {
      _setError('Sign in failed: ${e.toString()}');
      return false;
    } finally {
      _setLoading(false);
    }
  }
  
  Future<bool> signUp(String email, String password, String name) async {
    _setLoading(true);
    _clearError();
    
    try {
      final response = await _supabaseService.signUp(email, password);
      
      if (response.user != null) {
        // Create user profile in database
        await _supabaseService.createUserProfile(response.user!.id, name, email);
        debugPrint('User profile created for: ${response.user!.email}');
        
        // Load the profile we just created
        await _loadUserProfile();
      }
      
      return true;
    } catch (e) {
      _setError('Sign up failed: ${e.toString()}');
      return false;
    } finally {
      _setLoading(false);
    }
  }
  
  Future<void> signOut() async {
    try {
      await _supabaseService.signOut();
      _userProfile = null;
      _currentUser = null;
      _isProfileLoaded = false;
      _clearError();
      notifyListeners();
    } catch (e) {
      _setError('Sign out failed: ${e.toString()}');
    }
  }
  
  Future<void> _loadUserProfile() async {
    if (_currentUser == null) {
      _isProfileLoaded = false;
      return;
    }
    
    try {
      debugPrint('Loading user profile for: ${_currentUser!.id}');
      _userProfile = await _supabaseService.getUserProfile(_currentUser!.id);
      _isProfileLoaded = true;
      _clearError();
      debugPrint('User profile loaded: ${_userProfile!.name}');
      notifyListeners();
    } catch (e) {
      debugPrint('Failed to load user profile: $e');
      _userProfile = null;
      _isProfileLoaded = false;
      _setError('Failed to load user profile. Please ensure your account is properly set up.');
      notifyListeners();
    }
  }
  
  Future<bool> updateProfile(UserModel updatedProfile) async {
    _setLoading(true);
    _clearError();
    
    try {
      await _supabaseService.updateUserProfile(updatedProfile);
      _userProfile = updatedProfile;
      notifyListeners();
      return true;
    } catch (e) {
      _setError('Failed to update profile: ${e.toString()}');
      return false;
    } finally {
      _setLoading(false);
    }
  }
  
  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }
  
  void _setError(String error) {
    _errorMessage = error;
    notifyListeners();
  }
  
  void _clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}
