import 'package:flutter/foundation.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';

class AppConfig {
  static String get supabaseUrl {
    final url = dotenv.env['SUPABASE_URL'] ?? 'https://dqhsbihxysuhnkrdzpzu.supabase.co';
    debugPrint('Supabase URL: $url');
    return url;
  }
  
  static String get supabaseAnonKey {
    final key = dotenv.env['SUPABASE_ANON_KEY'] ?? 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRxaHNiaWh4eXN1aG5rcmR6cHp1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc5OTQxNDAsImV4cCI6MjA2MzU3MDE0MH0.elLaRGF33l_SwvMvSIxLNNSW8hj7xCcoG-caDEBNAfA';
    debugPrint('Supabase key available: ${key.isNotEmpty}');
    return key;
  }
  
  // Store your OpenAI API key here (for development only)
  // In production, use environment variables or secure storage
  static String get openAIApiKey => dotenv.env['OPENAI_API_KEY'] ?? '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';
  
  // Spiral Dynamics Colors
  static const Map<String, Map<String, dynamic>> spiralColors = {
    'beige': {
      'name': 'Beige - Survival',
      'color': 0xFFF5F5DC,
      'description': 'Basic survival instincts, immediate needs'
    },
    'purple': {
      'name': 'Purple - Tribal',
      'color': 0xFF800080,
      'description': 'Tribal bonds, magical thinking, safety in group'
    },
    'red': {
      'name': 'Red - Power',
      'color': 0xFFFF0000,
      'description': 'Power, dominance, immediate gratification'
    },
    'blue': {
      'name': 'Blue - Order',
      'color': 0xFF0000FF,
      'description': 'Rules, order, discipline, meaning and purpose'
    },
    'orange': {
      'name': 'Orange - Achievement',
      'color': 0xFFFFA500,
      'description': 'Success, achievement, competition, progress'
    },
    'green': {
      'name': 'Green - Community',
      'color': 0xFF008000,
      'description': 'Harmony, equality, feelings, community'
    },
    'yellow': {
      'name': 'Yellow - Integration',
      'color': 0xFFFFFF00,
      'description': 'Flexibility, integration, natural systems'
    },
    'turquoise': {
      'name': 'Turquoise - Holistic',
      'color': 0xFF40E0D0,
      'description': 'Holistic thinking, global perspective, synthesis'
    },
  };
  
  // Emotion Categories
  static const List<String> emotionCategories = [
    'Joy', 'Sadness', 'Anger', 'Fear', 'Surprise', 'Disgust',
    'Love', 'Gratitude', 'Hope', 'Anxiety', 'Excitement', 'Calm'
  ];
}
