import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';
import '../services/supabase_service.dart';

class AuthProvider with ChangeNotifier {
  final SupabaseService _supabaseService = SupabaseService();

  User? _user;
  UserModel? _userProfile;
  bool _isLoading = true;
  bool _isFirstTime = false;
  String? _errorMessage;

  User? get user => _user;
  User? get currentUser => _user;
  UserModel? get userProfile => _userProfile;
  bool get isLoading => _isLoading;
  bool get isFirstTime => _isFirstTime;
  String? get errorMessage => _errorMessage;
  bool get isAuthenticated => _user != null;

  AuthProvider() {
    _initializeAuth();
  }

  void _initializeAuth() {
    Supabase.instance.client.auth.onAuthStateChange.listen((data) {
      final event = data.event;
      final session = data.session;

      debugPrint('Auth state changed: $event');

      if (event == AuthChangeEvent.signedIn && session?.user != null) {
        _handleSignIn(session!.user);
      } else if (event == AuthChangeEvent.signedOut) {
        _handleSignOut();
      } else if (event == AuthChangeEvent.initialSession && session?.user != null) {
        _handleSignIn(session!.user);
      }
    });

    final session = Supabase.instance.client.auth.currentSession;
    if (session?.user != null) {
      _handleSignIn(session!.user);
    } else {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> _handleSignIn(User user) async {
    try {
      _user = user;
      _errorMessage = null;

      try {
        _userProfile = await _supabaseService.getUserProfile(user.id);
        // Check if profile needs completion based on existing data
        _isFirstTime = !_userProfile!.isProfileComplete;
      } catch (e) {
        debugPrint('User profile not found, creating new profile');
        await _createUserProfile(user);
        _isFirstTime = true;
      }

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      debugPrint('Error handling sign in: $e');
      _errorMessage = 'Failed to load user profile';
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> _createUserProfile(User user) async {
    try {
      final name = user.userMetadata?['full_name'] ??
          user.userMetadata?['name'] ??
          user.email?.split('@')[0] ??
          'User';

      await _supabaseService.createUserProfile(
        user.id,
        name,
        user.email ?? '',
      );

      _userProfile = await _supabaseService.getUserProfile(user.id);
    } catch (e) {
      debugPrint('Error creating user profile: $e');
      throw Exception('Failed to create user profile');
    }
  }

  void _handleSignOut() {
    _user = null;
    _userProfile = null;
    _isFirstTime = false;
    _errorMessage = null;
    _isLoading = false;
    notifyListeners();
  }

  Future<bool> signIn(String email, String password) async {
    return await signInWithEmail(email: email, password: password);
  }

  Future<bool> signInWithEmail({
    required String email,
    required String password,
  }) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      final response = await Supabase.instance.client.auth.signInWithPassword(
        email: email,
        password: password,
      );

      if (response.user != null) {
        return true;
      } else {
        _errorMessage = 'Sign in failed';
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } on AuthException catch (e) {
      debugPrint('Sign in error: $e');
      String errorMessage = 'Sign in failed';
      
      if (e.message.toLowerCase().contains('invalid login credentials')) {
        errorMessage = 'Invalid email or password. Please try again.';
      } else if (e.message.toLowerCase().contains('email not confirmed')) {
        errorMessage = 'Please check your email and confirm your account.';
      } else if (e.message.toLowerCase().contains('too many requests')) {
        errorMessage = 'Too many attempts. Please try again later.';
      } else {
        errorMessage = e.message;
      }
      
      _errorMessage = errorMessage;
      _isLoading = false;
      notifyListeners();
      return false;
    } catch (e) {
      debugPrint('Sign in error: $e');
      _errorMessage = 'An unexpected error occurred. Please try again.';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> signUp(String email, String password, String name) async {
    return await signUpWithEmail(email: email, password: password, name: name);
  }

  Future<bool> signUpWithEmail({
    required String email,
    required String password,
    required String name,
  }) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      final response = await Supabase.instance.client.auth.signUp(
        email: email,
        password: password,
        data: {'name': name, 'full_name': name},
      );

      if (response.user != null) {
        // Don't create profile here, let _handleSignIn do it
        return true;
      } else {
        _errorMessage = 'Sign up failed';
        _isLoading = false;
        notifyListeners();
        return false;
      }
    } on AuthException catch (e) {
      debugPrint('Sign up error: $e');
      String errorMessage = 'Sign up failed';
      
      if (e.message.toLowerCase().contains('user already registered') ||
          e.message.toLowerCase().contains('email already registered') ||
          e.message.toLowerCase().contains('already been registered')) {
        errorMessage = 'An account with this email already exists. Please sign in instead.';
      } else if (e.message.toLowerCase().contains('password')) {
        errorMessage = 'Password must be at least 6 characters long.';
      } else if (e.message.toLowerCase().contains('email')) {
        errorMessage = 'Please enter a valid email address.';
      } else {
        errorMessage = e.message;
      }
      
      _errorMessage = errorMessage;
      _isLoading = false;
      notifyListeners();
      return false;
    } catch (e) {
      debugPrint('Sign up error: $e');
      _errorMessage = 'An unexpected error occurred. Please try again.';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> signInWithGoogle() async {
    try {
      print('🔄 Starting Google sign in');
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      // Set redirect URL for Netlify deployment
      String? redirectUrl;
      if (kIsWeb) {
        final host = Uri.base.host;
        if (host.contains('localhost')) {
          redirectUrl = 'http://localhost:${Uri.base.port}';
        } else if (host.contains('netlify.app')) {
          redirectUrl = 'https://retven-nr.netlify.app';
        } else {
          redirectUrl = Uri.base.origin;
        }
      }

      final response = await Supabase.instance.client.auth.signInWithOAuth(
        OAuthProvider.google,
        redirectTo: redirectUrl,
      );

      print('✅ Google OAuth initiated: $response');

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      print('❌ Google sign in error: $e');
      _errorMessage = 'Google sign in failed. Please try again.';
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<void> signOut() async {
    try {
      _isLoading = true;
      notifyListeners();
      await _supabaseService.signOut();
    } catch (e) {
      debugPrint('Sign out error: $e');
      _errorMessage = 'Sign out failed';
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> updateProfile(UserModel updatedUser) async {
    try {
      await _supabaseService.updateUserProfile(updatedUser);
      _userProfile = updatedUser;
      notifyListeners();
      return true;
    } catch (e) {
      debugPrint('Update profile error: $e');
      _errorMessage = 'Failed to update profile';
      notifyListeners();
      return false;
    }
  }

  Future<void> completeOnboarding() async {
    _isFirstTime = false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboarding_completed', true);
    notifyListeners();
  }

  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}
